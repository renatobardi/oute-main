# OUTE Database - Excalidraw Mermaid Diagrams
> Corrigido para compatibilidade com Excalidraw:
> - Tipos normalizados (string, int, boolean)
> - UK removido (não suportado)
> - Comentários %% removidos dos blocos erDiagram
> - Auto-relacionamento de template_issues removido
>
> **Como importar**: Menu > Insert > Mermaid > colar o diagrama desejado.

---

## 1. Identity & Access (IAM)

```mermaid
erDiagram
    users {
        string id PK
        string email
        string password_hash
        string name
        string avatar_url
        string last_login_at
        string created_at
        string updated_at
        string deleted_at
    }

    organizations {
        string id PK
        string name
        string slug
        string logo_url
        string settings
        string created_at
        string updated_at
        string deleted_at
    }

    organization_members {
        string id PK
        string organization_id FK
        string user_id FK
        string role
        string joined_at
        string created_at
        string updated_at
        string deleted_at
    }

    refresh_tokens {
        string id PK
        string user_id FK
        string token_hash
        string device_info
        string expires_at
        boolean revoked
        string created_at
        string updated_at
        string deleted_at
    }

    users ||--o{ organization_members : "has memberships"
    organizations ||--o{ organization_members : "has members"
    users ||--o{ refresh_tokens : "has tokens"
```

---

## 2. Project Management

```mermaid
erDiagram
    projects {
        string id PK
        string organization_id FK
        string created_by FK
        string code
        string name
        string description
        string status
        string type
        int progress_percent
        string created_at
        string updated_at
        string deleted_at
    }

    project_members {
        string id PK
        string project_id FK
        string user_id FK
        string role
        string created_at
        string updated_at
        string deleted_at
    }

    tags {
        string id PK
        string organization_id FK
        string name
        string color
        string category
        string created_at
        string updated_at
        string deleted_at
    }

    project_tags {
        string id PK
        string project_id FK
        string tag_id FK
        string created_at
    }

    projects ||--o{ project_members : "has members"
    projects ||--o{ project_tags : "tagged with"
    tags ||--o{ project_tags : "applied to"
```

---

## 3. Interview & Chat

```mermaid
erDiagram
    interviews {
        string id PK
        string project_id FK
        string conducted_by FK
        string title
        string status
        string interview_code
        int total_messages
        string started_at
        string completed_at
        string created_at
        string updated_at
        string deleted_at
    }

    messages {
        string id PK
        string interview_id FK
        string user_id FK
        string sender
        string type
        string content
        string metadata
        string created_at
        string updated_at
        string deleted_at
    }

    interview_notes {
        string id PK
        string interview_id FK
        string last_edited_by FK
        string summary
        string content
        string metrics
        string tags_snapshot
        string created_at
        string updated_at
        string deleted_at
    }

    interviews ||--o{ messages : "contains"
    interviews ||--|| interview_notes : "has notes"
```

---

## 4. SDLC Template Engine

```mermaid
erDiagram
    sdlc_templates {
        string id PK
        string version
        string name
        string description
        boolean is_active
        int total_milestones
        int total_epics
        int total_issues
        string published_at
        string created_at
        string updated_at
        string deleted_at
    }

    template_milestones {
        string id PK
        string template_id FK
        int sort_order
        string code
        string name
        string objective
        string applicability_tags
        boolean is_required
        string created_at
        string updated_at
        string deleted_at
    }

    template_epics {
        string id PK
        string milestone_id FK
        int sort_order
        string name
        string description
        string applicability_tags
        string created_at
        string updated_at
        string deleted_at
    }

    template_issues {
        string id PK
        string epic_id FK
        string parent_issue_id FK
        int sort_order
        string name
        string how_to_fill
        string description_template
        string applicability_tags
        string metadata
        int depth
        string created_at
        string updated_at
        string deleted_at
    }

    template_checklist_items {
        string id PK
        string issue_id FK
        int sort_order
        string label
        boolean is_critical
        string created_at
        string updated_at
        string deleted_at
    }

    sdlc_templates ||--o{ template_milestones : "has milestones"
    template_milestones ||--o{ template_epics : "has epics"
    template_epics ||--o{ template_issues : "has issues"
    template_issues ||--o{ template_checklist_items : "has checklist"
```

---

## 5. Estimation Engine

```mermaid
erDiagram
    estimation_sessions {
        string id PK
        string project_id FK
        string template_id FK
        string started_by FK
        string status
        int overall_progress
        string config
        string started_at
        string completed_at
        string created_at
        string updated_at
        string deleted_at
    }

    estimation_milestone_statuses {
        string id PK
        string session_id FK
        string milestone_id FK
        string status
        string skip_reason
        string reviewer_verdict
        string reviewed_by FK
        int progress_percent
        string started_at
        string completed_at
        string created_at
        string updated_at
        string deleted_at
    }

    estimation_responses {
        string id PK
        string session_id FK
        string issue_id FK
        string answered_by FK
        string answer
        string structured_data
        boolean is_complete
        string created_at
        string updated_at
        string deleted_at
    }

    estimation_checklist_results {
        string id PK
        string session_id FK
        string checklist_item_id FK
        boolean is_checked
        string note
        string checked_by FK
        string checked_at
        string created_at
        string updated_at
        string deleted_at
    }

    estimation_outputs {
        string id PK
        string session_id FK
        string output_type
        string result
        string architecture_decisions
        string compliance_summary
        int confidence_score
        int estimated_hours_min
        int estimated_hours_max
        int estimated_budget_min
        int estimated_budget_max
        string currency
        string generated_at
        string created_at
        string updated_at
        string deleted_at
    }

    estimation_sessions ||--o{ estimation_milestone_statuses : "tracks milestones"
    estimation_sessions ||--o{ estimation_responses : "collects answers"
    estimation_sessions ||--o{ estimation_checklist_results : "checks items"
    estimation_sessions ||--o{ estimation_outputs : "generates"
```

---

## 6. Integrations

```mermaid
erDiagram
    integration_connections {
        string id PK
        string organization_id FK
        string created_by FK
        string provider
        string name
        string credentials_encrypted
        string config
        boolean is_active
        string last_synced_at
        string created_at
        string updated_at
        string deleted_at
    }

    export_sessions {
        string id PK
        string estimation_session_id FK
        string integration_connection_id FK
        string triggered_by FK
        string status
        int items_total
        int items_exported
        string error_log
        string export_config
        string started_at
        string completed_at
        string created_at
        string updated_at
        string deleted_at
    }

    export_mappings {
        string id PK
        string export_session_id FK
        string internal_entity_type
        string internal_entity_id
        string external_entity_type
        string external_entity_id
        string external_url
        string sync_metadata
        string last_synced_at
        string created_at
        string updated_at
        string deleted_at
    }

    integration_connections ||--o{ export_sessions : "used by"
    export_sessions ||--o{ export_mappings : "maps entities"
```

---

## 7. Audit

```mermaid
erDiagram
    audit_log {
        string id PK
        string organization_id FK
        string user_id FK
        string entity_type
        string entity_id
        string action
        string old_values
        string new_values
        string ip_address
        string user_agent
        string created_at
    }
```

---

## 8. Cross-Context Relationships

```mermaid
erDiagram
    users {
        string id PK
    }

    organizations {
        string id PK
    }

    projects {
        string id PK
        string organization_id FK
        string created_by FK
    }

    interviews {
        string id PK
        string project_id FK
        string conducted_by FK
    }

    sdlc_templates {
        string id PK
    }

    estimation_sessions {
        string id PK
        string project_id FK
        string template_id FK
        string started_by FK
    }

    integration_connections {
        string id PK
        string organization_id FK
        string created_by FK
    }

    export_sessions {
        string id PK
        string estimation_session_id FK
        string integration_connection_id FK
        string triggered_by FK
    }

    audit_log {
        string id PK
        string organization_id FK
        string user_id FK
    }

    users ||--o{ projects : "creates"
    users ||--o{ interviews : "conducts"
    users ||--o{ estimation_sessions : "starts"
    users ||--o{ integration_connections : "sets up"
    users ||--o{ export_sessions : "triggers"
    users ||--o{ audit_log : "performed by"
    organizations ||--o{ projects : "owns"
    organizations ||--o{ integration_connections : "connects"
    organizations ||--o{ audit_log : "audited"
    projects ||--o{ interviews : "has interviews"
    projects ||--o{ estimation_sessions : "estimated via"
    sdlc_templates ||--o{ estimation_sessions : "uses template"
    estimation_sessions ||--o{ export_sessions : "exported via"
    integration_connections ||--o{ export_sessions : "used by"
```
